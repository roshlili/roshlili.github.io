from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def hello_world():
    return render_template('home.html')

@app.route("/count/<int:i>")
def count(i):

    return render_template('count.html', i=i)

@app.route("/words/<string:s>/")
def words(s):
    f = open ('words_list.txt') 
    word_list = f.read().splitlines()

    l = []

    for word in word_list:
        if sorted(word.upper()) == sorted(s.upper()):
            l.append(word)
            
    return render_template('words.html', l = l)