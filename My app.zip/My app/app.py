from flask import Flask, render_template
import os
app = Flask(__name__)


@app.route("/")
def start(): #начало
    title = "The mysterious bus stop"

    image = "/static/open_screen.jpg"
    
    text = """This stop is fully functional, but there is a slight oddity with it..."""

    choices = [
        ('bus_1',"Find out what's going wrong with the bus stop"),
        ('walk_away',"Walk away!"),
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)

@app.route("/bus_1") #дорога
def bus_1():
    title = "You are brave, since you decided to learn more about the mystery of the bus stop"
    
    image = "/static/road.jpeg"

    text = """Here is a hint. The road is in great condition, but no bus ever came here. But passengers come here to get their bus..."""

    choices = [
        ('visitors',"Learn more about passengers"),
        ('walk_away',"Quit and walk away")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)

@app.route("/walk") #дорога
def walk_away():
    title = "You left and never found out the mystery of the stop"
    
    image = "/static/walk.webp"

    text = """Maybe next time :)"""

    choices = []

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)

@app.route("/visitors") #посетители
def visitors():
    title = "You are about to learn the biggest mystery about the place: it actually has visitors"
    
    image = "/static/person.jpeg"

    text = """Each day people come hear to get a bus but why: the bus still never arrived. You are one step away from pearning the purpose of the bus stop."""

    choices = [
        ('solve',"Find out why they come to the bus stop"),
        ('walk_away',"Quit and walk away")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)

@app.route("/solve") #разгадка
def solve():
    title = "You got to the bottom of the bus stop mystery"
    
    image = "/static/hospital.jpeg"

    text = """This bus stop is across the street from the hospital for mentally ill patients. Every day one of them tries to escape from there and comes to the bus stop. So they wait there until the hospital staff picks them up. This is why the bus never came there."""

    choices = [
        ('end',"Finish the game"),
        ('walk_away',"Quit and wallk away")
    ]

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)

@app.route("/end") #конец
def end():
    title = "You finished a game!"
    
    image = "/static/walk.webp"

    text = """Well done!"""

    choices = []
    print(os.getcwd())

    return render_template('adventure.html', title=title, text=text, choices=choices, image = image)